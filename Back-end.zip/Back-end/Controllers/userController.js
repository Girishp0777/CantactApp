const asynchandler = require('express-async-handler');
const bcrypt = require('bcrypt');
const jwt=require('jsonwebtoken')
const user=require('../Models/userModels');


//@desc register for user
//@route POST/api/user/register
//access public

const registeruser = asynchandler(async (req, res) => {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
        return res.status(400).json({ message: "All Fields are mandatory" });
    }

    const userAvailable = await user.findOne({ email });

    if (userAvailable) {
        return res.status(400).json({ message: "This email already exists" });
    }

    const hashedpassword = await bcrypt.hash(password, 10);

    try {
        const newuser = await user.create({
            username,
            email,
            password: hashedpassword,
        });

        console.log("Successfully created account", newuser);

        return res.status(200).json({ _id: newuser.id, email: newuser.email });
    } catch (error) {
        console.error("Error creating account:", error);
        return res.status(500).json({ message: "Internal Server Error" });
    }
});


//@desc login for user
//@route POST/api/user/login
//access public
const loginuser = asynchandler(async (req, res) => {
    const {email, password}=req.body;
    if(!email||!password)
    {
        res.status(400).json({message:"All Fields Are Mandatory"});
    } 

    const newuser= await user.findOne({email});
    if(newuser && (await bcrypt.compare(password,newuser.password)))
    {
        const accessToken= jwt.sign({
            newuser : {
                name:newuser.username,
                email:newuser.email,
                _id:newuser.id
            },
         },
         process.env.accessToken_Secret,
         {expiresIn:"15m"}
         )
         res.status(200).json({accessToken});
    }else{
        res.status(400).json({message:"Invalid email and password"})
    }
   
});

//@desc current user
//@route GET/api/user/current
//access private
const current = asynchandler(async (req, res) => {
    res.json(req.newuser._id);
});

module.exports = { registeruser, loginuser, current };
