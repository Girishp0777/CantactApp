const asynchandler= require('express-async-handler')
const contact = require("../Models/contactmodels")

//@desc contact
//@route GET/api/contacts
//access private
const getcontact =asynchandler(async(req, res) => {
    const contacts=await contact.find({user_id : req.newuser._id});
    res.status(200).json(contacts);
});

//@desc create new contact
//@route POST/api/contacts
//access private
const createContact = async (req, res, next) => {
    try {
        const { name, email, phone } = req.body;

        if (!name || !email || !phone) {
            return res.status(400).json({ title: 'Validation Error', message: 'All fields are mandatory' });
        }
        const newContact = await contact.create({
            name,
            email,
            phone,
            user_id: req.newuser._id,
        });

        console.log('Contact Created:', newContact);
        return res.status(201).json(newContact);
    } catch (error) {
        console.error('Error Creating Contact:', error);
        return next(error);
    }
};



// @desc Get contact by ID
// @route GET /api/contacts/:id
// @access private

const getContactById = asynchandler(async (req, res) => {
    const Contact = await contact.findById(req.params.id);
  
    if (!Contact) {
      return res.status(404).json({ message: "Contact not found" });
    }
    if (Contact.user_id.toString() == req.newuser._id) {
        res.status(200).json(Contact)
    }
    if (Contact.user_id.toString() !== req.newuser._id) {
        res.status(403).json({ message: "you Don't  Get this contacts" });
    }
  });
  
//@desc Update contact
//@route PUT/api/contacts
//access private

const updatecontact = asynchandler(async (req, res) => {
    const Contact = await contact.findById(req.params.id);
        if (!Contact) {
            res.status(404);
            throw new Error({message: "Contact not found" });
        }
        if (Contact.user_id.toString() == req.newuser._id ) {
            const updatedcontact= await contact.findByIdAndUpdate(
                req.params.id,
                req.body,
                { new: true}
            )
            res.status(200).json(updatedcontact);
        }
        if (Contact.user_id.toString() !== req.newuser._id) {
            res.status(403).json({ message: "you cannot update This contacts" });
        }
});

//@desc delete contact
//@route DELETE/api/contacts
//access private

const deletecontact = asynchandler(async (req, res) => {
    const Contact = await contact.findById(req.params.id);
    if (!Contact) {
        return res.status(404).json({ message: "Contact not found" });
    }
    if (Contact.user_id.toString() == req.newuser._id) {
        const deleted= await contact.findByIdAndDelete(req.params.id)
          res.status(200).json(deleted)
    }
    if (Contact.user_id.toString() !== req.newuser._id) {
          res.status(403).json({ message: "you Cannot Delete this contacts" });
    }
});

module.exports={  getcontact, createContact ,getContactById, updatecontact, deletecontact};

