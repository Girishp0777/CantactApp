var express="this is my appp"
console.log(express);