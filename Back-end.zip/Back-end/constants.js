exports.constants = {
    Validation_Error: 400,
    Unauthorized: 401,
    Forbidden: 403,
    Not_Found: 404,
    Server_Error: 500,
};
