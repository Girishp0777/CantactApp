const express = require("express");
const router = express.Router();
const { registeruser, loginuser, current } = require("../Controllers/userController");
const validationToken = require("../Middleware/validationTokenhandler");

router.post("/register", registeruser);
router.post("/login", loginuser);
router.get("/current", validationToken ,current);

module.exports = router;
