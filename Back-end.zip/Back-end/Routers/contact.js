const express = require('express');
const router = express.Router();
const { getcontact, createContact, getContactById, updatecontact, deletecontact } = require('../Controllers/contact.js');
const validationToken = require('../Middleware/validationTokenhandler.js');


router.use(validationToken);

router.route('/')
  .get(getcontact)
  .post(validationToken,createContact);

router.route('/:id')
  .get(getContactById)
  .put(updatecontact)
  .delete(deletecontact);




module.exports = router;
