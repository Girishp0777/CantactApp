/*const express = require("express");
const dotenv= require('dotenv').config();
const errorhandler = require("./Middleware/errorhandler.js");
const connectdb = require("./Config/dbconnection.js");

const app = express();
const port = 5000;


connectdb();

app.use(express.json());

app.use("/api/contacts", require("./Routers/contact.js"));
app.use(errorhandler);


app.use("/api/products", require("./Routers/product.js"));

app.use("/api/orders", require("./Routers/order"));

app.use("/api/contact", require("./Controllers/contact"));

app.listen(port, () => {
    console.log('Server running on Port ' + port);
});*/
const express = require("express");
const dotenv = require('dotenv').config();
const errorhandler = require("./Middleware/errorhandler.js");
const connectdb = require("./Config/dbconnection.js");
const validationToken = require("./Middleware/validationTokenhandler.js");

const app = express();
const port = 5000;

connectdb();

app.use(express.json());

app.use("/api/contacts", require("./Routers/contact.js"));

app.use("/api/user", require("./Routers/userRouter.js"));

// Error handling middleware (place it after your routes)
app.use(errorhandler);


app.listen(port, () => {
    console.log('Server running on Port ' + port);
});
