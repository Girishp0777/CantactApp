const { constants } = require('../constants');

const errorhandler = (err, req, res, next) => {
  const statuscode = err.statuscode || 400; 

  switch (statuscode) {
    case constants.Validation_Error:
      res.status(400).json({
        title: "Validation Error",
        message: err.message,
        StackTrace: err.StackTrace,
      });
      break;
    case constants.Unauthorized:
      res.status(401).json({
        title: "UNAUTHORIZED",
        message: err.message,
        StackTrace: err.StackTrace,
      });
      break;
    case constants.Forbidden:
      res.status(403).json({
        title: "Forbidden",
        message: err.message,
        StackTrace: err.StackTrace,
      });
      break;
    case constants.Not_Found:
      res.status(404).json({
        title: "Not Found",
        message: err.message,
        StackTrace: err.StackTrace,
      });
      break;
    case constants.Server_Error:
      res.status(500).json({
        title: "Server Error",
        message: err.message,
        StackTrace: err.StackTrace,
      });
      break;
    default:
      res.status(statuscode).json({
        title: "Unknown Error",
        message: err.message,
        StackTrace: err.StackTrace,
      });
      break;
  }
};

module.exports = errorhandler;

